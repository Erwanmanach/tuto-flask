from .app import app, db
import tuto.view
import tuto.commands
import tuto.models
